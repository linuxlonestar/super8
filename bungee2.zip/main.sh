#!/bin/bash
echo starting...
cd bungee
java -Xmx1024M -Xms1024M -jar bungee.jar
